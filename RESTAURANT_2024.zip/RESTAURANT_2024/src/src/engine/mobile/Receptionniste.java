package engine.mobile;

import engine.map.Block;

public class Receptionniste extends Staff {
	
	public Receptionniste(int argent, Block position) {
		super(argent, position);
	}
}
