package engine.process;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}