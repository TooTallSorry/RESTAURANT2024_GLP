package engine.outil;

import engine.map.Block;

public class Cuisine extends Emplacement {
	
	public Cuisine(Block position) {
		super(position);
	}
}
