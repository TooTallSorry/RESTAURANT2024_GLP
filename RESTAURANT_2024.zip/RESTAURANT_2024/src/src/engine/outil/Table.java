package engine.outil;

import engine.map.Block;

public class Table extends Emplacement {
	
	public Table(Block position) {
		super(position);
		
	}
}