package system;

public class Temps {
	private int secondes;
	
	public Temps(int secondes) {
		this.secondes = secondes;
	}
}
