package system;

public class Tips {
	private int argent;
	
	public Tips(int argent) {
		this.argent = argent;
	}
}
