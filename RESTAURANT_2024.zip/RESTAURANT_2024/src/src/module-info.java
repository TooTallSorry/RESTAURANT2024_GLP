/**
 * 
 */
/**
 * 
 */
module V1 {
	requires java.desktop;
	requires junit;
	requires org.junit.jupiter.api;
}