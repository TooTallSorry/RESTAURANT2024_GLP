![Logo de Sea-cret de la Mer](https://media.discordapp.net/attachments/1200518585949356064/1234622681412796457/seacret_de_la_mer.png?ex=66316779&is=663015f9&hm=d76ea399f94317e79be0a80b990b3024aa98ddb8791096cc04edfebdb52b7e33&=&format=webp&quality=lossless&width=669&height=676)

# Sea-cret de la Mer

Bienvenue sur **Sea-cret de la Mer**, votre jeu de gestion de restaurant.

## Guide d'utilisation

- Lancez votre eclipse et créer un nouveau projet Java. 

- Copiez collez les  fichiers du répertoire `src` dans votre projet Java.

- Allez dans le package "test" et  ouvrez le fichier "TestGame.java".

## Support

En cas de questions ou de problèmes avec l'utilisation du jeu, n'hésitez pas à contacter notre support technique via email à zijawed984@gmail.com.

## Auteurs

- **CHEBALLAH Jawed**
- **MAKUISA Andrew**
- **REY Timothé**

## But du Projet

Ce projet a été développé dans le cadre du cours de Génie Logiciel de L2 Informatique à l'Université de Cergy.

## URL Utilisées

- [GitHUB](https://github.com/DrewVII/Seacret)

